import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { COURSE_PROGRESS_API } from "@/lib/apiBaseUrl";

export const courseProgressApi = createApi({
    reducerPath: "courseProgressApi",
    baseQuery: fetchBaseQuery({
        baseUrl: COURSE_PROGRESS_API,
        credentials: 'include'
    }),
    endpoints: (builder) => ({
        getCourseProgress: builder.query({
            query: (courseId) => ({
                url: `/${courseId}`,
                method: "GET"
            })
        }),
        updateLectureProgress: builder.mutation({
            query: ({ courseId, lectureId }) => ({
                url: `/${courseId}/lecture/${lectureId}/view`,
                method: "POST"
            })
        }),
        toggleLectureProgress: builder.mutation({
            query: ({ courseId, lectureId }) => ({
                url: `/${courseId}/lecture/${lectureId}/toggle`,
                method: "POST"
            })
        }),
        completeCourse: builder.mutation({
            query: (courseId) => ({
                url: `/${courseId}/complete`,
                method: "POST"
            })
        }),
        inCompleteCourse: builder.mutation({
            query: (courseId) => ({
                url: `/${courseId}/incomplete`,
                method: "POST"
            })
        }),
    })
})

export const {
    useGetCourseProgressQuery,
    useUpdateLectureProgressMutation,
    useToggleLectureProgressMutation,
    useCompleteCourseMutation,
    useInCompleteCourseMutation
} = courseProgressApi;