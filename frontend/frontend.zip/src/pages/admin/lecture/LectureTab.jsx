import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { useEditLectureMutation, useGetLectureByIdQuery, useRemoveLectureMutation } from '@/features/api/courseApi'
import { MEDIA_API } from '@/lib/apiBaseUrl'
import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { toast } from 'sonner'

const getErrorMessage = (error, fallbackMessage) => {
    if (!error) return fallbackMessage;
    if (typeof error?.data?.message === "string") return error.data.message;
    if (typeof error?.error === "string") return error.error;
    return fallbackMessage;
}

const LectureTab = () => {
    const [lectureTitle, setLectureTitle] = useState("");
    const [uploadVideoInfo, setUploadVideoInfo] = useState(null);
    const [isFree, setIsFree] = useState(false);
    // "idle" | "uploading" | "success" | "error"
    const [uploadStatus, setUploadStatus] = useState("idle");
    const params = useParams();
    const { courseId, lectureId } = params;

    const { data: lectureData } = useGetLectureByIdQuery(lectureId);
    const lecture = lectureData?.lecture;

    useEffect(() => {
        if (lecture) {
            setLectureTitle(lecture.lectureTitle);
            setIsFree(lecture.isPreviewFree);
            // FIX: lecture model stores videoUrl and publicId as flat fields,
            // NOT nested under a "videoInfo" object. Build the object correctly.
            if (lecture.videoUrl) {
                setUploadVideoInfo({ videoUrl: lecture.videoUrl, publicId: lecture.publicId });
                setUploadStatus("success");
            }
        }
    }, [lecture]);

    const [editLecture, { data, error, isSuccess }] = useEditLectureMutation();
    const [removeLecture, { data: removeData, error: removeError, isSuccess: removeSuccess }] = useRemoveLectureMutation();

    const fileChangeHandler = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append("file", file);
        setUploadStatus("uploading");
        try {
            const res = await axios.post(`${MEDIA_API}/upload-video`, formData);
            if (res.data.success) {
                setUploadVideoInfo({ videoUrl: res.data.data.secure_url, publicId: res.data.data.public_id });
                setUploadStatus("success");
                toast.success(res.data.message);
            } else {
                setUploadStatus("error");
                toast.error("Upload failed");
            }
        } catch (error) {
            console.log(error);
            setUploadStatus("error");
            toast.error("Video upload failed");
        }
    };

    const editLectureHandler = async () => {
        await editLecture({ lectureTitle, videoInfo: uploadVideoInfo, isPreviewFree: isFree, courseId, lectureId });
    };

    const removeLectureHandler = async () => {
        await removeLecture(lectureId);
    };

    useEffect(() => {
        if (isSuccess) toast.success(data?.message || "Lecture updated successfully.");
        if (error) toast.error(getErrorMessage(error, "Failed to update lecture."));
    }, [isSuccess, error]);

    useEffect(() => {
        if (removeSuccess) toast.success(removeData?.message || "Lecture removed successfully.");
        if (removeError) toast.error(getErrorMessage(removeError, "Failed to remove lecture."));
    }, [removeSuccess, removeData, removeError]);

    const statusDisplay = {
        idle: null,
        uploading: <p className="text-sm text-blue-600 font-medium mt-2">Uploading...</p>,
        success: <p className="text-sm text-green-600 font-medium mt-2">✓ Video uploaded successfully</p>,
        error: <p className="text-sm text-red-600 font-medium mt-2">✗ Upload failed — please try again</p>,
    };

    return (
        <Card>
            <CardHeader className="flex justify-between">
                <div>
                    <CardTitle>Edit Lecture</CardTitle>
                    <CardDescription>Make changes and click save when done.</CardDescription>
                </div>
                <div className='flex items-center gap-2'>
                    <Button variant="destructive" onClick={removeLectureHandler}>Remove Lecture</Button>
                </div>
            </CardHeader>
            <CardContent>
                <div>
                    <Label>Title</Label>
                    <Input
                        type="text"
                        value={lectureTitle}
                        onChange={(e) => setLectureTitle(e.target.value)}
                        placeholder="Ex. Introduction to Javascript"
                    />
                </div>

                <div className='my-5'>
                    <Label>Video <span className='text-red-500'>*</span></Label>
                    {/* Show existing video URL as confirmation if already saved */}
                    {uploadVideoInfo?.videoUrl && uploadStatus !== "uploading" && (
                        <p className="text-xs text-gray-500 mb-1 break-all">
                            Current: {uploadVideoInfo.videoUrl}
                        </p>
                    )}
                    <Input
                        type="file"
                        accept='video/*'
                        onChange={fileChangeHandler}
                        className="w-fit"
                        disabled={uploadStatus === "uploading"}
                    />
                    {statusDisplay[uploadStatus]}
                </div>

                <div className='flex items-center space-x-2 my-5'>
                    <Switch checked={isFree} onCheckedChange={setIsFree} id="preview-free" />
                    <Label htmlFor="preview-free">Is this video FREE?</Label>
                </div>

                <div className='mt-4'>
                    <Button
                        onClick={editLectureHandler}
                        disabled={uploadStatus === "uploading"}
                    >
                        Update Lecture
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
};

export default LectureTab;