import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardTitle } from "@/components/ui/card";
import {
  useCompleteCourseMutation,
  useGetCourseProgressQuery,
  useInCompleteCourseMutation,
  useToggleLectureProgressMutation,
  useUpdateLectureProgressMutation,
} from "@/features/api/courseProgressApi";
import { CheckCircle, CheckCircle2, CirclePlay } from "lucide-react";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import ReactPlayer from "react-player";
import { toast } from "sonner";

const CourseProgress = () => {
  const params = useParams();
  const courseId = params.courseId;

  const { data, isLoading, isError, refetch } = useGetCourseProgressQuery(courseId);
  const [updateLectureProgress] = useUpdateLectureProgressMutation();
  const [toggleLectureProgress] = useToggleLectureProgressMutation();

  const [completeCourse, { data: markCompleteData, isSuccess: completedSuccess }] =
    useCompleteCourseMutation();
  const [inCompleteCourse, { data: markInCompleteData, isSuccess: inCompletedSuccess }] =
    useInCompleteCourseMutation();

  const [currentLecture, setCurrentLecture] = useState(null);

  useEffect(() => {
    if (completedSuccess) {
      refetch();
      toast.success(markCompleteData?.message || "Course marked as completed.");
    }
    if (inCompletedSuccess) {
      refetch();
      toast.success(markInCompleteData?.message || "Course marked as incomplete.");
    }
  }, [completedSuccess, inCompletedSuccess]);

  if (isLoading) return <p>Loading...</p>;
  if (isError) return <p>Failed to load course details</p>;

  const { courseDetails, progress, completed } = data.data;
  const { courseTitle } = courseDetails;

  const activeLecture = currentLecture || courseDetails.lectures?.[0];
  const activeVideoUrl = activeLecture?.videoUrl || null;

  const isLectureCompleted = (lectureId) =>
    progress.some((prog) => prog.lectureId === lectureId && prog.viewed);

  // When video finishes — mark lecture as viewed (never toggles, only marks complete)
  const handleVideoEnd = async () => {
    if (!activeLecture?._id) return;
    await updateLectureProgress({ courseId, lectureId: activeLecture._id });
    refetch();
  };

  // Clicking a sidebar lecture: switch video + toggle its completion state
  const handleSelectLecture = async (lecture) => {
    setCurrentLecture(lecture);
    await toggleLectureProgress({ courseId, lectureId: lecture._id });
    refetch();
  };

  return (
    <div className="max-w-7xl mx-auto p-4">
      {/* Header */}
      <div className="flex justify-between mb-4">
        <h1 className="text-2xl font-bold">{courseTitle}</h1>
        <Button
          onClick={completed
            ? async () => { await inCompleteCourse(courseId); }
            : async () => { await completeCourse(courseId); }}
          variant={completed ? "outline" : "default"}
        >
          {completed ? (
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              <span>Completed</span>
            </div>
          ) : (
            "Mark as completed"
          )}
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Video player */}
        <div className="flex-1 md:w-3/5 rounded-lg shadow-lg p-4">
          {activeVideoUrl ? (
            <>
              {/*
                ReactPlayer handles Cloudinary URLs, CORS, and format negotiation
                far better than a native <video> tag. The key prop still forces a
                full remount when the lecture changes so the new URL loads cleanly.
              */}
              <ReactPlayer
                key={activeLecture._id}
                url={activeVideoUrl}
                controls
                width="100%"
                height="auto"
                style={{ aspectRatio: "16/9" }}
                onEnded={handleVideoEnd}
                config={{
                  file: {
                    attributes: {
                      controlsList: "nodownload",
                    },
                  },
                }}
              />
            </>
          ) : (
            <div className="w-full aspect-video bg-gray-100 dark:bg-gray-800 flex items-center justify-center rounded-lg">
              <p className="text-gray-500 text-sm">
                No video available for this lecture yet.
              </p>
            </div>
          )}

          <div className="mt-3">
            <h3 className="font-medium text-lg">
              {`Lecture ${
                courseDetails.lectures.findIndex((lec) => lec._id === activeLecture?._id) + 1
              } : ${activeLecture?.lectureTitle}`}
            </h3>
          </div>
        </div>

        {/* Lecture sidebar */}
        <div className="flex flex-col w-full md:w-2/5 border-t md:border-t-0 md:border-l border-gray-200 md:pl-4 pt-4 md:pt-0">
          <h2 className="font-semibold text-xl mb-1">Course Lectures</h2>
          <p className="text-xs text-gray-400 mb-4">
            Click a lecture to play it · click again to toggle completion
          </p>
          <div className="flex-1 overflow-y-auto">
            {courseDetails?.lectures.map((lecture) => {
              const done = isLectureCompleted(lecture._id);
              const isActive = activeLecture?._id === lecture._id;
              return (
                <Card
                  key={lecture._id}
                  className={`mb-3 cursor-pointer transition-colors ${
                    isActive ? "bg-gray-200 dark:bg-gray-800" : "hover:bg-gray-50 dark:hover:bg-gray-900"
                  }`}
                  onClick={() => handleSelectLecture(lecture)}
                >
                  <CardContent className="flex items-center justify-between p-4">
                    <div className="flex items-center gap-2">
                      {done ? (
                        <CheckCircle2 size={22} className="text-green-500 shrink-0" />
                      ) : (
                        <CirclePlay size={22} className="text-gray-400 shrink-0" />
                      )}
                      <CardTitle className="text-base font-medium leading-snug">
                        {lecture?.lectureTitle}
                      </CardTitle>
                    </div>
                    {done && (
                      <Badge variant="outline" className="bg-green-100 text-green-600 shrink-0 ml-2">
                        Done
                      </Badge>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseProgress;